create definer = root@`%` view base_category_view as
select `c1`.`id`   AS `category1_id`,
       `c1`.`name` AS `category1_name`,
       `c2`.`id`   AS `category2_id`,
       `c2`.`name` AS `category2_name`,
       `c3`.`id`   AS `category3_id`,
       `c3`.`name` AS `category3_name`
from ((`tingshu_album`.`base_category1` `c1` join `tingshu_album`.`base_category2` `c2`
       on ((`c1`.`id` = `c2`.`category1_id`))) join `tingshu_album`.`base_category3` `c3`
      on ((`c2`.`id` = `c3`.`category2_id`)));

-- comment on column base_category_view.category1_id not supported: 编号

-- comment on column base_category_view.category1_name not supported: 分类名称

-- comment on column base_category_view.category2_id not supported: 编号

-- comment on column base_category_view.category2_name not supported: 二级分类名称

-- comment on column base_category_view.category3_id not supported: 编号

-- comment on column base_category_view.category3_name not supported: 三级分类名称

